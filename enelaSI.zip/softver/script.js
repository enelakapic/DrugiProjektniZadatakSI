var textWrapper = document.querySelector('.card-details');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.card-details .letter',
    scale: [4,1],
    opacity: [0,1],
    translateZ: 0,
    easing: "easeOutExpo",
    duration: 200,  
    delay: (el, i) => 20*i  
  }).add({
    targets: '.card-details',
    opacity: 0,
    duration: 300,  
    easing: "easeOutExpo",
    delay: 2300  
  });


  window.addEventListener('load', function () {
    const preloader = document.getElementById('preloader');
    if (preloader) {
        anime({
            targets: preloader,
            opacity: [1, 0], 
            duration: 4000,  
            easing: 'easeOutQuad',
            complete: function () {
                document.body.classList.add('loaded');
                preloader.style.display = 'none';
            }
        });
    } else {
        console.error("Preloader element not found!");
    }
});

document.addEventListener('DOMContentLoaded', function () {
  const images = document.querySelectorAll('.image-container img');
  images.forEach(img => img.classList.add('loaded'));
});
